import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function AdminBook() {
const [products, setProducts] = useState([]);
const [adminData, setAdminData] = useState({});
const [selectedProduct, setSelectedProduct] = useState(null);
const [borrowMode, setBorrowMode] = useState(false);
const navigate = useNavigate();

const [borrowData, setBorrowData] = useState({
customerName: '',
quantity: 1,
amount: 0
});

useEffect(() => {
fetch('http://localhost:8080/api/products')
.then(res => res.json())
.then(data => setProducts(data._embedded?.products || []));

```
const stored = JSON.parse(localStorage.getItem('adminProductData') || '{}');
setAdminData(stored);
```

}, []);

// ================= BORROW =================
const handleBorrowSave = () => {
if (!selectedProduct) return;

```
const updated = { ...adminData };

const productData = updated[selectedProduct.id] || {
  stock: 0,
  borrowRecords: []
};

const newBorrow = {
  customerName: borrowData.customerName,
  quantity: Number(borrowData.quantity),
  amount: Number(borrowData.amount),
  status: "PENDING",
  date: new Date().toISOString()
};

productData.stock = (productData.stock || 0) - newBorrow.quantity;

productData.borrowRecords = [
  ...(productData.borrowRecords || []),
  newBorrow
];

updated[selectedProduct.id] = productData;

localStorage.setItem('adminProductData', JSON.stringify(updated));
setAdminData(updated);

setBorrowMode(false);
setBorrowData({ customerName: '', quantity: 1, amount: 0 });
```

};

// ================= PAID =================
const markAsPaid = (productId, index) => {
const updated = { ...adminData };
updated[productId].borrowRecords[index].status = "PAID";

```
localStorage.setItem('adminProductData', JSON.stringify(updated));
setAdminData(updated);
```

};

// ================= WHATSAPP =================
const sendWhatsApp = (b) => {
const msg = `Hello ${b.customerName}, pending ₹${b.amount}. Please pay 🙏`;
window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank");
};

// ================= DASHBOARD =================
const getStats = () => {
let pending = 0;
let paid = 0;
let customers = new Set();

```
Object.values(adminData).forEach(p => {
  (p.borrowRecords || []).forEach(b => {
    customers.add(b.customerName);
    if (b.status === "PENDING") pending += b.amount;
    else paid += b.amount;
  });
});

return { pending, paid, customers: customers.size };
```

};

const stats = getStats();

// ================= CUSTOMER DATA =================
const getCustomers = () => {
const map = {};

```
Object.entries(adminData).forEach(([pid, pdata]) => {
  (pdata.borrowRecords || []).forEach(b => {
    if (!map[b.customerName]) map[b.customerName] = [];

    map[b.customerName].push({
      ...b,
      productName: products.find(p => p.id == pid)?.name
    });
  });
});

return map;
```

};

return ( <div className="container mt-3">

```
  <h2>📒 Admin Book</h2>

  {/* Dashboard */}
  <div className="row mb-3">
    <div className="col">Pending ₹ {stats.pending}</div>
    <div className="col">Paid ₹ {stats.paid}</div>
    <div className="col">Customers {stats.customers}</div>
  </div>

  {/* Products */}
  <h3>Products</h3>
  <table className="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Stock</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody>
      {products.map(p => (
        <tr key={p.id}>
          <td>{p.name}</td>
          <td>{adminData[p.id]?.stock || 0}</td>
          <td>
            <button
              className="btn btn-warning"
              onClick={() => {
                setSelectedProduct(p);
                setBorrowMode(true);
              }}
            >
              Borrow
            </button>
          </td>
        </tr>
      ))}
    </tbody>
  </table>

  {/* Customers */}
  <h3>Customers</h3>
  {Object.entries(getCustomers()).map(([name, records]) => (
    <div key={name}>
      <button
        className="btn btn-link"
        onClick={() =>
          navigate("/customer-ledger", {
            state: { customerName: name, records }
          })
        }
      >
        {name}
      </button>
    </div>
  ))}

  {/* Borrow Modal */}
  {borrowMode && (
    <div className="card p-3 mt-3">
      <h4>Add Borrow</h4>

      <input
        className="form-control mb-2"
        placeholder="Customer Name"
        value={borrowData.customerName}
        onChange={e => setBorrowData({ ...borrowData, customerName: e.target.value })}
      />

      <input
        type="number"
        className="form-control mb-2"
        placeholder="Quantity"
        value={borrowData.quantity}
        onChange={e => setBorrowData({ ...borrowData, quantity: e.target.value })}
      />

      <input
        type="number"
        className="form-control mb-2"
        placeholder="Amount"
        value={borrowData.amount}
        onChange={e => setBorrowData({ ...borrowData, amount: e.target.value })}
      />

      <button className="btn btn-success" onClick={handleBorrowSave}>
        Save
      </button>
    </div>
  )}

  {/* Records */}
  <h3 className="mt-4">Borrow Records</h3>

  {Object.entries(adminData).map(([pid, pdata]) =>
    (pdata.borrowRecords || []).map((b, i) => (
      <div key={i} className="card p-2 mt-2">
        <b>{b.customerName}</b> - ₹ {b.amount} - {b.status}

        {b.status === "PENDING" && (
          <>
            <button
              className="btn btn-success btn-sm ms-2"
              onClick={() => markAsPaid(pid, i)}
            >
              Paid
            </button>

            <button
              className="btn btn-primary btn-sm ms-2"
              onClick={() => sendWhatsApp(b)}
            >
              WhatsApp
            </button>
          </>
        )}
      </div>
    ))
  )}

</div>


);
}


import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import CategoryProducts from "./components/CategoryProducts";
import AddProduct from "./components/AddProduct";

export default function App(){
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/category/:category" element={<CategoryProducts />} />
        <Route path="/add" element={<AddProduct />} />
      </Routes>
    </BrowserRouter>
  )
}

import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { NavLink, useNavigate } from "react-router-dom";

export default function Register() {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    defaultValues: {
      username: "",
      email: "",
      password: "",
      conformPassword: "",
      mobile: "",
      roles: [],
    },
  });

  const [formError, setFormError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const navigate = useNavigate();
  const passwordValue = watch("password");

  async function registerUser(formData) {
    if (formData.password !== formData.conformPassword) {
      setFormError("Passwords do not match.");
      return;
    }
    setFormError(null);
    setLoading(true);
    try {
      const resp = await fetch("http://localhost:8080/api/register", {
        headers: { "Content-Type": "application/json" },
        method: "POST",
        body: JSON.stringify(formData),
      });
      const data = await resp.json();
      if (data.status === 400) {
        setFormError(data.message);
      } else {
        navigate("/login", { state: { registered: true } });
      }
    } catch {
      setFormError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

        .reg-page {
          min-height: 100vh;
          background: #0d0d0d;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 3rem 1rem;
          font-family: 'DM Sans', sans-serif;
          position: relative;
          overflow: hidden;
        }

        .reg-page::before, .reg-page::after {
          content: '';
          position: absolute;
          border-radius: 50%;
          filter: blur(90px);
          pointer-events: none;
        }
        .reg-page::before {
          width: 380px; height: 380px;
          background: #c9a96e;
          top: -100px; left: -80px;
          opacity: 0.12;
        }
        .reg-page::after {
          width: 300px; height: 300px;
          background: #c9a96e;
          bottom: -80px; right: -60px;
          opacity: 0.07;
        }

        .reg-card {
          background: #161616;
          border: 1px solid #222;
          border-radius: 20px;
          padding: 2.8rem 2.5rem 2.5rem;
          width: 100%;
          max-width: 460px;
          position: relative;
          z-index: 1;
          box-shadow: 0 32px 80px rgba(0,0,0,0.6);
          animation: cardIn 0.45s cubic-bezier(.22,.68,0,1.2) both;
        }

        @keyframes cardIn {
          from { opacity: 0; transform: translateY(24px) scale(0.97); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        .reg-eyebrow {
          font-size: 0.65rem;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: #c9a96e;
          margin-bottom: 0.5rem;
        }

        .reg-heading {
          font-family: 'DM Serif Display', serif;
          font-size: 2rem;
          color: #f0ece4;
          letter-spacing: -0.02em;
          margin-bottom: 0.25rem;
          line-height: 1;
        }

        .reg-heading em { font-style: italic; color: #c9a96e; }

        .reg-sub {
          font-size: 0.82rem;
          color: #555;
          margin-bottom: 2rem;
        }

        .reg-divider {
          height: 1px;
          background: #222;
          margin-bottom: 1.75rem;
        }

        /* ── ERROR BANNER ── */
        .reg-error {
          background: rgba(220,80,80,0.08);
          border: 1px solid rgba(220,80,80,0.25);
          border-radius: 9px;
          padding: 0.7rem 1rem;
          font-size: 0.82rem;
          color: #e07070;
          margin-bottom: 1.4rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          animation: shake 0.35s ease;
        }

        @keyframes shake {
          0%,100% { transform: translateX(0); }
          25%      { transform: translateX(-5px); }
          75%      { transform: translateX(5px); }
        }

        /* ── TWO-COL ROW ── */
        .field-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        /* ── FIELD ── */
        .field { margin-bottom: 1.15rem; }

        .field-label {
          display: block;
          font-size: 0.68rem;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #666;
          margin-bottom: 0.4rem;
        }

        .field-wrap { position: relative; }

        .field-input {
          width: 100%;
          background: #0d0d0d;
          border: 1px solid #2a2a2a;
          border-radius: 9px;
          padding: 0.68rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.86rem;
          color: #f0ece4;
          outline: none;
          box-sizing: border-box;
          transition: border-color 0.2s, box-shadow 0.2s;
        }

        .field-input::placeholder { color: #333; }

        .field-input:focus {
          border-color: #c9a96e;
          box-shadow: 0 0 0 3px rgba(201,169,110,0.1);
        }

        .field-input.has-error { border-color: rgba(220,80,80,0.45); }

        .field-error {
          font-size: 0.72rem;
          color: #e07070;
          margin-top: 0.3rem;
        }

        /* pw toggle */
        .pw-toggle {
          position: absolute;
          right: 0.85rem;
          top: 50%;
          transform: translateY(-50%);
          background: none;
          border: none;
          cursor: pointer;
          color: #444;
          padding: 0;
          line-height: 1;
          transition: color 0.2s;
        }
        .pw-toggle:hover { color: #c9a96e; }

        /* ── ROLE CHECKBOXES ── */
        .role-section {
          margin-bottom: 1.4rem;
        }

        .role-label-heading {
          font-size: 0.68rem;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #666;
          margin-bottom: 0.65rem;
          display: block;
        }

        .role-options {
          display: flex;
          gap: 0.75rem;
        }

        .role-chip {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          background: #0d0d0d;
          border: 1px solid #2a2a2a;
          border-radius: 8px;
          padding: 0.5rem 0.9rem;
          cursor: pointer;
          transition: border-color 0.2s;
          user-select: none;
        }

        .role-chip:has(input:checked) {
          border-color: #c9a96e;
          background: rgba(201,169,110,0.06);
        }

        .role-chip input[type="checkbox"] {
          accent-color: #c9a96e;
          width: 14px;
          height: 14px;
          cursor: pointer;
        }

        .role-chip span {
          font-size: 0.78rem;
          color: #888;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          font-weight: 500;
        }

        .role-chip:has(input:checked) span { color: #c9a96e; }

        /* ── SUBMIT ── */
        .btn-register {
          width: 100%;
          background: #c9a96e;
          border: none;
          border-radius: 9px;
          padding: 0.78rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.9rem;
          font-weight: 600;
          color: #0d0d0d;
          cursor: pointer;
          transition: background 0.2s, transform 0.15s, opacity 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          letter-spacing: 0.02em;
        }

        .btn-register:hover:not(:disabled) { background: #debb85; transform: translateY(-1px); }
        .btn-register:active:not(:disabled) { transform: translateY(0); }
        .btn-register:disabled { opacity: 0.6; cursor: not-allowed; }

        .spinner {
          width: 15px; height: 15px;
          border: 2px solid rgba(0,0,0,0.2);
          border-top-color: #0d0d0d;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
          flex-shrink: 0;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* ── FOOTER ── */
        .reg-footer {
          text-align: center;
          margin-top: 1.6rem;
          font-size: 0.82rem;
          color: #555;
        }

        .reg-footer a {
          color: #c9a96e;
          text-decoration: none;
          font-weight: 500;
          transition: color 0.2s;
        }

        .reg-footer a:hover { color: #debb85; }

        @media (max-width: 480px) {
          .reg-card { padding: 2rem 1.4rem 2rem; }
          .field-row { grid-template-columns: 1fr; }
        }
      `}</style>

      <div className="reg-page">
        <div className="reg-card">

          {/* Heading */}
          <p className="reg-eyebrow">Join us today</p>
          <h1 className="reg-heading">Create <em>account</em></h1>
          <p className="reg-sub">Fill in the details below to get started.</p>
          <div className="reg-divider" />

          {formError && (
            <div className="reg-error">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
              </svg>
              {formError}
            </div>
          )}

          <form onSubmit={handleSubmit(registerUser)} noValidate>

            {/* Username + Mobile */}
            <div className="field-row">
              <div className="field">
                <label className="field-label">Username</label>
                <input
                  type="text"
                  placeholder="johndoe"
                  className={`field-input ${errors.username ? 'has-error' : ''}`}
                  {...register("username", { required: "Username is required" })}
                />
                {errors.username && <p className="field-error">{errors.username.message}</p>}
              </div>

              <div className="field">
                <label className="field-label">Mobile</label>
                <input
                  type="tel"
                  placeholder="98765 43210"
                  className={`field-input ${errors.mobile ? 'has-error' : ''}`}
                  {...register("mobile", {
                    required: "Mobile is required",
                    pattern: { value: /^[6-9]\d{9}$/, message: "Enter a valid 10-digit number" }
                  })}
                />
                {errors.mobile && <p className="field-error">{errors.mobile.message}</p>}
              </div>
            </div>

            {/* Email */}
            <div className="field">
              <label className="field-label">Email address</label>
              <input
                type="email"
                placeholder="you@example.com"
                className={`field-input ${errors.email ? 'has-error' : ''}`}
                {...register("email", {
                  required: "Email is required",
                  pattern: { value: /\S+@\S+\.\S+/, message: "Enter a valid email" }
                })}
              />
              {errors.email && <p className="field-error">{errors.email.message}</p>}
            </div>

            {/* Password + Confirm */}
            <div className="field-row">
              <div className="field">
                <label className="field-label">Password</label>
                <div className="field-wrap">
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    style={{ paddingRight: '2.8rem' }}
                    className={`field-input ${errors.password ? 'has-error' : ''}`}
                    {...register("password", {
                      required: "Password is required",
                      minLength: { value: 6, message: "Min. 6 characters" }
                    })}
                  />
                  <button type="button" className="pw-toggle" onClick={() => setShowPassword(!showPassword)}>
                    {showPassword
                      ? <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                      : <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    }
                  </button>
                </div>
                {errors.password && <p className="field-error">{errors.password.message}</p>}
              </div>

              <div className="field">
                <label className="field-label">Confirm password</label>
                <div className="field-wrap">
                  <input
                    type={showConfirm ? "text" : "password"}
                    placeholder="••••••••"
                    style={{ paddingRight: '2.8rem' }}
                    className={`field-input ${errors.conformPassword ? 'has-error' : ''}`}
                    {...register("conformPassword", {
                      required: "Please confirm your password",
                      validate: v => v === passwordValue || "Passwords do not match"
                    })}
                  />
                  <button type="button" className="pw-toggle" onClick={() => setShowConfirm(!showConfirm)}>
                    {showConfirm
                      ? <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                      : <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    }
                  </button>
                </div>
                {errors.conformPassword && <p className="field-error">{errors.conformPassword.message}</p>}
              </div>
            </div>

            {/* Role chips */}
            <div className="role-section">
              <span className="role-label-heading">Account role</span>
              <div className="role-options">
                <label className="role-chip">
                  <input type="checkbox" value="ROLE_USER" {...register("roles")} defaultChecked />
                  <span>User</span>
                </label>
                <label className="role-chip">
                  <input type="checkbox" value="ROLE_ADMIN" {...register("roles")} />
                  <span>Admin</span>
                </label>
              </div>
            </div>

            {/* Submit */}
            <button className="btn-register" type="submit" disabled={loading}>
              {loading ? (
                <><div className="spinner" /> Creating account…</>
              ) : (
                <>
                  Create account
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <line x1="5" y1="12" x2="19" y2="12"/>
                    <polyline points="12 5 19 12 12 19"/>
                  </svg>
                </>
              )}
            </button>
          </form>

          <p className="reg-footer">
            Already have an account?{" "}
            <NavLink to="/login">Sign in</NavLink>
          </p>
        </div>
      </div>
    </>
  );
}
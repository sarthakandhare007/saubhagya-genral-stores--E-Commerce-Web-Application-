import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { jwtDecode } from "jwt-decode";
import { NavLink, useNavigate } from "react-router-dom";

export default function Login() {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm();
  const navigate = useNavigate();
  const [loginError, setLoginError] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  async function doLogin(formData) {
    setLoginError(null);
    setLoading(true);
    try {
      const resp = await fetch("http://localhost:8080/api/login", {
        headers: { "Content-Type": "application/json" },
        method: "POST",
        body: JSON.stringify(formData),
      });

      if (resp.status === 401) {
        setLoginError("Invalid email or password. Please try again.");
        setLoading(false);
        return;
      }

      const data = await resp.json();
      const token = data.jwtToken;
      localStorage.setItem("jwtToken", token);

      const decoded = jwtDecode(token);
      const parts = decoded.sub.split(",");
      localStorage.setItem("userId", parts[0]);
      localStorage.setItem("username", parts[2]);
      localStorage.setItem("roles", decoded.sub.split("[")[1]);

      window.location.href = "http://localhost:3000";
    } catch (err) {
      setLoginError("Something went wrong. Please try again.");
      setLoading(false);
    }
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

        .login-page {
          min-height: 100vh;
          background: #0d0d0d;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 2rem 1rem;
          font-family: 'DM Sans', sans-serif;
          position: relative;
          overflow: hidden;
        }

        /* decorative blobs */
        .login-page::before,
        .login-page::after {
          content: '';
          position: absolute;
          border-radius: 50%;
          filter: blur(80px);
          pointer-events: none;
          opacity: 0.18;
        }
        .login-page::before {
          width: 420px; height: 420px;
          background: #c9a96e;
          top: -120px; right: -80px;
        }
        .login-page::after {
          width: 300px; height: 300px;
          background: #c9a96e;
          bottom: -80px; left: -60px;
          opacity: 0.08;
        }

        .login-card {
          background: #161616;
          border: 1px solid #222;
          border-radius: 20px;
          padding: 2.8rem 2.5rem 2.5rem;
          width: 100%;
          max-width: 420px;
          position: relative;
          z-index: 1;
          box-shadow: 0 32px 80px rgba(0,0,0,0.6);
          animation: cardIn 0.45s cubic-bezier(.22,.68,0,1.2) both;
        }

        @keyframes cardIn {
          from { opacity: 0; transform: translateY(24px) scale(0.97); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* ── TOP MARK ── */
        .login-eyebrow {
          font-size: 0.65rem;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: #c9a96e;
          margin-bottom: 0.5rem;
        }

        .login-heading {
          font-family: 'DM Serif Display', serif;
          font-size: 2rem;
          color: #f0ece4;
          letter-spacing: -0.02em;
          margin-bottom: 0.25rem;
          line-height: 1;
        }

        .login-heading em { font-style: italic; color: #c9a96e; }

        .login-sub {
          font-size: 0.82rem;
          color: #555;
          margin-bottom: 2.2rem;
        }

        /* ── DIVIDER LINE ── */
        .login-divider {
          height: 1px;
          background: #222;
          margin-bottom: 2rem;
        }

        /* ── ERROR ── */
        .login-error {
          background: rgba(220, 80, 80, 0.08);
          border: 1px solid rgba(220, 80, 80, 0.25);
          border-radius: 9px;
          padding: 0.7rem 1rem;
          font-size: 0.82rem;
          color: #e07070;
          margin-bottom: 1.5rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          animation: shake 0.35s ease;
        }

        @keyframes shake {
          0%,100% { transform: translateX(0); }
          25%      { transform: translateX(-6px); }
          75%      { transform: translateX(6px); }
        }

        /* ── FIELD ── */
        .field {
          margin-bottom: 1.25rem;
        }

        .field-label {
          display: block;
          font-size: 0.72rem;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #666;
          margin-bottom: 0.45rem;
        }

        .field-wrap {
          position: relative;
        }

        .field-input {
          width: 100%;
          background: #0d0d0d;
          border: 1px solid #2a2a2a;
          border-radius: 9px;
          padding: 0.72rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.88rem;
          color: #f0ece4;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
          box-sizing: border-box;
        }

        .field-input::placeholder { color: #3a3a3a; }

        .field-input:focus {
          border-color: #c9a96e;
          box-shadow: 0 0 0 3px rgba(201,169,110,0.1);
        }

        .field-input.has-error {
          border-color: rgba(220, 80, 80, 0.5);
        }

        .field-error {
          font-size: 0.75rem;
          color: #e07070;
          margin-top: 0.35rem;
        }

        /* password toggle */
        .pw-toggle {
          position: absolute;
          right: 0.85rem;
          top: 50%;
          transform: translateY(-50%);
          background: none;
          border: none;
          cursor: pointer;
          color: #444;
          padding: 0;
          line-height: 1;
          transition: color 0.2s;
        }

        .pw-toggle:hover { color: #c9a96e; }

        /* ── SUBMIT ── */
        .btn-login {
          width: 100%;
          background: #c9a96e;
          border: none;
          border-radius: 9px;
          padding: 0.78rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.9rem;
          font-weight: 600;
          color: #0d0d0d;
          cursor: pointer;
          margin-top: 0.5rem;
          transition: background 0.2s, transform 0.15s, opacity 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          letter-spacing: 0.02em;
        }

        .btn-login:hover:not(:disabled) { background: #debb85; transform: translateY(-1px); }
        .btn-login:active:not(:disabled) { transform: translateY(0); }
        .btn-login:disabled { opacity: 0.6; cursor: not-allowed; }

        /* spinner */
        .spinner {
          width: 15px; height: 15px;
          border: 2px solid rgba(0,0,0,0.2);
          border-top-color: #0d0d0d;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
          flex-shrink: 0;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        /* ── FOOTER ── */
        .login-footer {
          text-align: center;
          margin-top: 1.75rem;
          font-size: 0.82rem;
          color: #555;
        }

        .login-footer a {
          color: #c9a96e;
          text-decoration: none;
          font-weight: 500;
          transition: color 0.2s;
        }

        .login-footer a:hover { color: #debb85; }
      `}</style>

      <div className="login-page">
        <div className="login-card">

          {/* Heading */}
          <p className="login-eyebrow">Welcome back</p>
          <h1 className="login-heading">Sign <em>in</em></h1>
          <p className="login-sub">Enter your credentials to continue shopping.</p>
          <div className="login-divider" />

          <form onSubmit={handleSubmit(doLogin)} noValidate>

            {/* Error alert */}
            {loginError && (
              <div className="login-error">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="8" x2="12" y2="12"/>
                  <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                {loginError}
              </div>
            )}

            {/* Email */}
            <div className="field">
              <label className="field-label">Email address</label>
              <div className="field-wrap">
                <input
                  type="email"
                  className={`field-input ${errors.email ? 'has-error' : ''}`}
                  placeholder="you@example.com"
                  {...register("email", {
                    required: "Email is required",
                    pattern: { value: /\S+@\S+\.\S+/, message: "Enter a valid email" }
                  })}
                />
              </div>
              {errors.email && <p className="field-error">{errors.email.message}</p>}
            </div>

            {/* Password */}
            <div className="field">
              <label className="field-label">Password</label>
              <div className="field-wrap">
                <input
                  type={showPassword ? "text" : "password"}
                  className={`field-input ${errors.password ? 'has-error' : ''}`}
                  placeholder="••••••••"
                  style={{ paddingRight: '2.8rem' }}
                  {...register("password", { required: "Password is required" })}
                />
                <button
                  type="button"
                  className="pw-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label="Toggle password visibility"
                >
                  {showPassword ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
                      <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
                      <line x1="1" y1="1" x2="23" y2="23"/>
                    </svg>
                  ) : (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                      <circle cx="12" cy="12" r="3"/>
                    </svg>
                  )}
                </button>
              </div>
              {errors.password && <p className="field-error">{errors.password.message}</p>}
            </div>

            {/* Submit */}
            <button className="btn-login" type="submit" disabled={loading}>
              {loading ? (
                <><div className="spinner" /> Signing in…</>
              ) : (
                <>
                  Sign in
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <line x1="5" y1="12" x2="19" y2="12"/>
                    <polyline points="12 5 19 12 12 19"/>
                  </svg>
                </>
              )}
            </button>
          </form>

          {/* Footer */}
          <p className="login-footer">
            Don't have an account?{" "}
            <NavLink to="/register">Create one</NavLink>
          </p>
        </div>
      </div>
    </>
  );
}
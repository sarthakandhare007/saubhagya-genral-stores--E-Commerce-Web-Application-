import React, { useEffect, useState } from 'react'
import { NavLink, useNavigate, useParams } from 'react-router-dom'
import Product from './Product'

export default function ProductDetail() {
    const params = useParams();
    const [productDetails, setProductDetails] = useState(null);
    const [relatedProducts, setRelatedProducts] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [adminData, setAdminData] = useState(null);
    const [isAdding, setIsAdding] = useState(false);
    const roles = localStorage.getItem("roles");
    const token = localStorage.getItem("jwtToken");
    const userId = localStorage.getItem("userId");
    const navigate = useNavigate();

    useEffect(() => {
        // Fetch product details
        fetch(`http://localhost:8080/api/products/${params.id}`)
            .then(resp => resp.json())
            .then(data => {
                console.log(data)
                setProductDetails(data);
                
                // Fetch related products from same category
                if (data.category) {
                    const searchParams = new URLSearchParams();
                    searchParams.append("category", data.category);
                    fetch(`http://localhost:8080/api/search-products?${searchParams.toString()}`)
                        .then(r => r.json())
                        .then(d => {
                            // Filter out current product and limit to 4
                            const related = d.filter(p => p.id !== parseInt(params.id)).slice(0, 4);
                            setRelatedProducts(related);
                        })
                        .catch(err => console.error("Error fetching related products:", err));
                }
            })

        // Fetch admin data (stock, expenses) from localStorage
        const adminDataStored = JSON.parse(localStorage.getItem('adminProductData') || '{}');
        if (adminDataStored[params.id]) {
            setAdminData(adminDataStored[params.id]);
        }
    }, [params.id]);

    function deleteProduct(){
        const c = window.confirm("Do You Really Want To Delete Product '" + productDetails.name + "' ?");
        if(c){
            fetch(`http://localhost:8080/api/products/${params.id}`,
                {
                    headers:{"Authorization":`Bearer ${token}`},
                    method:"DELETE"
                }
            )
            .then(resp => {
                alert("Product Deleted Successfully..!!");
                navigate("/");
            })
        }
    }

    function addToCart(){
        if(roles && roles.includes("USER")){
            setIsAdding(true);
            const requestBody = {
                "user": `http://localhost:8080/api/users/${userId}`,
                "product": `http://localhost:8080/api/products/${params.id}`,
                "quantity": quantity
            }
            fetch('http://localhost:8080/api/carts',{
                headers: {
                    "Content-Type":"application/json",
                    "Authorization":`Bearer ${token}`
                },
                method:"POST",
                body:JSON.stringify(requestBody)
            })
            .then(resp => {
                console.log(resp);
                if (resp.ok) {
                    alert(`${quantity} item(s) added to cart!`);
                    setQuantity(1);
                } else {
                    alert("Failed to add to cart");
                }
            })
            .catch(err => {
                console.error("Error:", err);
                alert("An error occurred");
            })
            .finally(() => {
                setIsAdding(false);
            });
        }
        else{
            alert("Please Login First For Shopping");
            navigate("/login")
        }
    }

    return (
        <>
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

                * { box-sizing: border-box; }

                .product-detail-page {
                    background: #0d0d0d;
                    color: #f0ece4;
                    font-family: 'DM Sans', sans-serif;
                    padding: 2rem 1rem;
                    min-height: 100vh;
                }

                .detail-container {
                    max-width: 1200px;
                    margin: 0 auto;
                }

                .breadcrumb {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    font-size: 0.85rem;
                    color: #666;
                    margin-bottom: 2rem;
                }

                .breadcrumb a {
                    color: #999;
                    text-decoration: none;
                    transition: color 0.2s;
                }

                .breadcrumb a:hover {
                    color: #c9a96e;
                }

                .breadcrumb span {
                    color: #444;
                }

                .detail-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 3rem;
                    margin-top: 2rem;
                }

                /* Image section */
                .detail-image-wrap {
                    background: #161616;
                    border: 1px solid #222;
                    border-radius: 16px;
                    overflow: hidden;
                    aspect-ratio: 1;
                    position: relative;
                }

                .detail-image {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    display: block;
                    background: #111;
                }

                .detail-image-placeholder {
                    width: 100%;
                    height: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: #111;
                    color: #333;
                }

                /* Info section */
                .detail-info {
                    display: flex;
                    flex-direction: column;
                    justify-content: flex-start;
                }

                .detail-category {
                    font-size: 0.75rem;
                    letter-spacing: 0.15em;
                    text-transform: uppercase;
                    color: #c9a96e;
                    margin-bottom: 0.5rem;
                    font-weight: 600;
                }

                .detail-name {
                    font-family: 'DM Serif Display', serif;
                    font-size: 2rem;
                    color: #f0ece4;
                    margin-bottom: 0.5rem;
                    line-height: 1.2;
                }

                .detail-divider {
                    height: 1px;
                    background: #222;
                    margin: 1.5rem 0;
                }

                .detail-desc {
                    font-size: 0.95rem;
                    color: #999;
                    line-height: 1.6;
                    margin-bottom: 1.5rem;
                }

                /* Pricing section */
                .pricing-section {
                    background: #161616;
                    border: 1px solid #222;
                    border-radius: 12px;
                    padding: 1.5rem;
                    margin-bottom: 1.5rem;
                }

                .price-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 0.8rem 0;
                    border-bottom: 1px solid #222;
                }

                .price-item:last-child {
                    border-bottom: none;
                }

                .price-label {
                    font-size: 0.85rem;
                    color: #666;
                    letter-spacing: 0.05em;
                }

                .price-value {
                    font-size: 1.3rem;
                    font-weight: 600;
                    color: #f0ece4;
                }

                /* Quantity selector */
                .quantity-section {
                    background: #161616;
                    border: 1px solid #222;
                    border-radius: 12px;
                    padding: 1.5rem;
                    margin-bottom: 1.5rem;
                }

                .quantity-label {
                    font-size: 0.75rem;
                    letter-spacing: 0.15em;
                    text-transform: uppercase;
                    color: #666;
                    margin-bottom: 0.8rem;
                    display: block;
                }

                .quantity-controls {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                }

                .qty-btn {
                    background: #0d0d0d;
                    border: 1px solid #2a2a2a;
                    color: #f0ece4;
                    width: 40px;
                    height: 40px;
                    border-radius: 8px;
                    font-size: 1.2rem;
                    cursor: pointer;
                    transition: border-color 0.2s, background 0.2s;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }

                .qty-btn:hover {
                    border-color: #c9a96e;
                    background: #161616;
                }

                .qty-btn:disabled {
                    opacity: 0.3;
                    cursor: not-allowed;
                }

                .qty-display {
                    font-size: 1.2rem;
                    font-weight: 600;
                    color: #f0ece4;
                    min-width: 60px;
                    text-align: center;
                    padding: 0.5rem 1rem;
                    background: #0d0d0d;
                    border: 1px solid #2a2a2a;
                    border-radius: 8px;
                }

                /* Stock Information */
                .stock-section {
                    background: #161616;
                    border: 1px solid #222;
                    border-radius: 12px;
                    padding: 1.5rem;
                    margin-bottom: 1.5rem;
                }

                .stock-header {
                    font-size: 0.9rem;
                    font-weight: 600;
                    color: #f0ece4;
                    margin-bottom: 1rem;
                    letter-spacing: 0.05em;
                }

                .stock-info {
                    display: grid;
                    grid-template-columns: repeat(2, 1fr);
                    gap: 1rem;
                }

                .stock-item {
                    background: #0d0d0d;
                    border: 1px solid #2a2a2a;
                    border-radius: 8px;
                    padding: 1rem;
                }

                .stock-item-label {
                    font-size: 0.72rem;
                    letter-spacing: 0.1em;
                    text-transform: uppercase;
                    color: #666;
                    margin-bottom: 0.4rem;
                }

                .stock-item-value {
                    font-size: 1.1rem;
                    font-weight: 600;
                    color: #f0ece4;
                }

                .stock-item-unit {
                    font-size: 0.8rem;
                    color: #666;
                    margin-left: 0.3rem;
                    font-weight: 400;
                }

                .stock-badge {
                    display: inline-block;
                    margin-top: 0.5rem;
                    padding: 0.3rem 0.7rem;
                    border-radius: 6px;
                    font-size: 0.72rem;
                    font-weight: 600;
                    letter-spacing: 0.05em;
                }

                /* Action Buttons */
                .action-buttons {
                    display: flex;
                    gap: 1rem;
                    margin-top: 1.5rem;
                }

                .btn-action {
                    flex: 1;
                    padding: 0.9rem 1.5rem;
                    border-radius: 10px;
                    font-family: 'DM Sans', sans-serif;
                    font-size: 0.9rem;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.2s;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 0.5rem;
                    text-decoration: none;
                    border: none;
                }

                .btn-add-cart {
                    background: #c9a96e;
                    color: #0d0d0d;
                }

                .btn-add-cart:hover:not(:disabled) {
                    background: #debb85;
                    transform: translateY(-2px);
                }

                .btn-add-cart:disabled {
                    opacity: 0.6;
                    cursor: not-allowed;
                }

                .btn-edit {
                    background: transparent;
                    border: 1px solid #333;
                    color: #999;
                }

                .btn-edit:hover {
                    border-color: #c9a96e;
                    color: #c9a96e;
                }

                .btn-delete {
                    background: transparent;
                    border: 1px solid rgba(220,80,80,0.3);
                    color: #e07070;
                }

                .btn-delete:hover {
                    border-color: #e07070;
                    background: rgba(220,80,80,0.1);
                }

                .spinner-small {
                    width: 16px;
                    height: 16px;
                    border: 2px solid rgba(0,0,0,0.2);
                    border-top-color: #0d0d0d;
                    border-radius: 50%;
                    animation: spin 0.7s linear infinite;
                }

                @keyframes spin {
                    to { transform: rotate(360deg); }
                }

                /* Related Products */
                .related-section {
                    margin-top: 5rem;
                }

                .related-header {
                    font-family: 'DM Serif Display', serif;
                    font-size: 1.8rem;
                    color: #f0ece4;
                    margin-bottom: 2rem;
                    letter-spacing: -0.02em;
                }

                .related-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
                    gap: 1.5rem;
                }

                /* Responsive */
                @media (max-width: 968px) {
                    .detail-grid {
                        grid-template-columns: 1fr;
                        gap: 2rem;
                    }

                    .action-buttons {
                        flex-direction: column;
                    }

                    .btn-action {
                        justify-content: center;
                    }

                    .stock-info {
                        grid-template-columns: 1fr;
                    }
                }
            `}</style>

            <div className="product-detail-page">
                <div className="detail-container">
                    {/* Breadcrumb */}
                    <div className="breadcrumb">
                        <a href="/">Home</a>
                        <span>/</span>
                        {productDetails && (
                            <>
                                <a href={`/category/${encodeURIComponent(productDetails.category)}`}>
                                    {productDetails.category}
                                </a>
                                <span>/</span>
                                <span style={{color: '#c9a96e'}}>{productDetails.name}</span>
                            </>
                        )}
                    </div>

                    {productDetails && (
                        <div className="detail-grid">
                            {/* Image */}
                            <div className="detail-image-wrap">
                                {productDetails.imageUrl ? (
                                    <img
                                        src={productDetails.imageUrl}
                                        alt={productDetails.name}
                                        className="detail-image"
                                        onError={(e) => { e.target.style.display = 'none'; }}
                                    />
                                ) : (
                                    <div className="detail-image-placeholder">
                                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                                            <rect x="3" y="3" width="18" height="18" rx="2"/>
                                            <circle cx="8.5" cy="8.5" r="1.5"/>
                                            <polyline points="21 15 16 10 5 21"/>
                                        </svg>
                                    </div>
                                )}
                            </div>

                            {/* Info */}
                            <div className="detail-info">
                                <div className="detail-category">{productDetails.category}</div>
                                <h1 className="detail-name">{productDetails.name}</h1>
                                <div className="detail-divider" />
                                <p className="detail-desc">{productDetails.description}</p>

                                {/* Pricing */}
                                <div className="pricing-section">
                                    <div className="price-item">
                                        <span className="price-label">Selling Price</span>
                                        <span className="price-value">₹ {Number(productDetails.price).toLocaleString('en-IN')}</span>
                                    </div>
                                    {adminData && (
                                        <>
                                            <div className="price-item">
                                                <span className="price-label">Cost Price</span>
                                                <span className="price-value">₹ {Number(adminData.costPrice).toLocaleString('en-IN')}</span>
                                            </div>
                                            <div className="price-item">
                                                <span className="price-label">Profit per Unit</span>
                                                <span className="price-value" style={{ color: '#5fa75f' }}>
                                                    ₹ {(Number(productDetails.price) - Number(adminData.costPrice)).toLocaleString('en-IN')}
                                                </span>
                                            </div>
                                        </>
                                    )}
                                </div>

                                {/* Quantity Selector */}
                                {roles && roles.includes("USER") && (
                                    <div className="quantity-section">
                                        <label className="quantity-label">Quantity</label>
                                        <div className="quantity-controls">
                                            <button 
                                                className="qty-btn"
                                                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                                                disabled={quantity <= 1}
                                            >
                                                −
                                            </button>
                                            <div className="qty-display">{quantity}</div>
                                            <button 
                                                className="qty-btn"
                                                onClick={() => setQuantity(quantity + 1)}
                                            >
                                                +
                                            </button>
                                        </div>
                                    </div>
                                )}

                                {/* Stock Information */}
                                {adminData && (
                                    <div className="stock-section">
                                        <div className="stock-header">📦 Stock & Inventory</div>
                                        <div className="stock-info">
                                            <div className="stock-item">
                                                <div className="stock-item-label">Current Stock</div>
                                                <div className="stock-item-value">
                                                    {adminData.stock}
                                                    <span className="stock-item-unit">units</span>
                                                </div>
                                                <div className="stock-badge" style={{
                                                    background: adminData.stock === 0 
                                                        ? 'rgba(224, 112, 112, 0.2)'
                                                        : adminData.stock < 10
                                                        ? 'rgba(201, 169, 110, 0.2)'
                                                        : 'rgba(95, 167, 95, 0.2)',
                                                    color: adminData.stock === 0 
                                                        ? '#e07070'
                                                        : adminData.stock < 10
                                                        ? '#c9a96e'
                                                        : '#5fa75f'
                                                }}>
                                                    {adminData.stock === 0 
                                                        ? '⚠ Out of Stock'
                                                        : adminData.stock < 10
                                                        ? '⚠ Low Stock'
                                                        : '✓ In Stock'}
                                                </div>
                                            </div>

                                            <div className="stock-item">
                                                <div className="stock-item-label">Total Investment</div>
                                                <div className="stock-item-value">
                                                    ₹ {(adminData.stock * adminData.costPrice).toLocaleString('en-IN')}
                                                </div>
                                            </div>

                                            <div className="stock-item">
                                                <div className="stock-item-label">Expense per Unit</div>
                                                <div className="stock-item-value">
                                                    ₹ {Number(adminData.expensePerUnit).toLocaleString('en-IN')}
                                                </div>
                                            </div>

                                            <div className="stock-item">
                                                <div className="stock-item-label">Total Expenses</div>
                                                <div className="stock-item-value">
                                                    ₹ {Number(adminData.totalExpense).toLocaleString('en-IN')}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* Action Buttons */}
                                {roles && roles.includes("USER") && (
                                    <div className="action-buttons">
                                        <button className='btn-action btn-add-cart' onClick={addToCart} disabled={isAdding}>
                                            {isAdding ? (
                                                <>
                                                    <div className="spinner-small" />
                                                    Adding...
                                                </>
                                            ) : (
                                                <>
                                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                                                        <circle cx="9" cy="21" r="1" />
                                                        <circle cx="20" cy="21" r="1" />
                                                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                                                    </svg>
                                                    Add To Cart
                                                </>
                                            )}
                                        </button>
                                    </div>
                                )}

                                {roles && roles.includes("ADMIN") && (
                                    <div className="action-buttons">
                                        <NavLink 
                                            className='btn-action btn-edit'
                                            to={`/update/${params.id}`}
                                        >
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                                                <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
                                            </svg>
                                            Edit
                                        </NavLink>
                                        <button className='btn-action btn-delete' onClick={deleteProduct}>
                                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                                                <polyline points="3 6 5 6 21 6" />
                                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                                                <line x1="10" y1="11" x2="10" y2="17" />
                                                <line x1="14" y1="11" x2="14" y2="17" />
                                            </svg>
                                            Delete
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Related Products */}
                    {relatedProducts && relatedProducts.length > 0 && (
                        <div className="related-section">
                            <h2 className="related-header">You Might Also Like</h2>
                            <div className="related-grid">
                                {relatedProducts.map(prod => (
                                    <Product key={prod.id} prod={prod} />
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </>
    )
}
import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useNavigate, useParams } from 'react-router-dom';

export default function UpdateProduct() {
  const { register, handleSubmit, reset, watch, setValue, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const params = useParams();
  const [productDetails, setProductDetails] = useState(null);
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const roles = localStorage.getItem("roles");
  const token = localStorage.getItem("jwtToken");
  const [useFileUpload, setUseFileUpload] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:8080/api/products/${params.id}`)
      .then(resp => resp.json())
      .then(data => {
        setProductDetails(data);
        reset(data);
        if (data.imageUrl) {
          setImagePreview(data.imageUrl);
        }
      })
  }, [params.id, reset]);

  // Handle file upload
  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedImage(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  async function updateProduct(formData) {
    setSubmitError(null);
    setLoading(true);
    try {
      if (useFileUpload && uploadedImage) {
        // Using file upload - send as FormData
        const formDataToSend = new FormData();
        formDataToSend.append('name', formData.name);
        formDataToSend.append('category', formData.category);
        formDataToSend.append('price', Number(formData.price));
        formDataToSend.append('description', formData.description);
        formDataToSend.append('stock', Number(formData.stock) || 0);
        formDataToSend.append('expense', Number(formData.expense) || 0);
        formDataToSend.append('imageFile', uploadedImage);

        const resp = await fetch(`http://localhost:8080/api/products/${params.id}/upload`, {
          headers: {
            "Authorization": `Bearer ${token}`
          },
          method: "PUT",
          body: formDataToSend
        });

        if (resp.ok) {
          alert("Product updated successfully!");
          navigate("/");
        } else {
          setSubmitError("Failed to update product.");
        }
      } else {
        // Using URL - send as JSON
        const resp = await fetch(`http://localhost:8080/api/products/${params.id}`, {
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          },
          method: "PUT",
          body: JSON.stringify({
            ...formData,
            price: Number(formData.price),
            stock: Number(formData.stock) || 0,
            expense: Number(formData.expense) || 0
          })
        });

        if (resp.ok) {
          alert("Product updated successfully!");
          navigate("/");
        } else {
          setSubmitError("Failed to update product.");
        }
      }
    } catch (err) {
      setSubmitError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  const imageUrlValue = watch("imageUrl");
  const previewImageUrl = useFileUpload ? imagePreview : (imagePreview || imageUrlValue);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

        .up-page {
          min-height: 100vh;
          background: #0d0d0d;
          display: flex;
          align-items: flex-start;
          justify-content: center;
          padding: 3.5rem 1rem 5rem;
          font-family: 'DM Sans', sans-serif;
          position: relative;
          overflow: hidden;
        }

        .up-page::before {
          content: '';
          position: absolute;
          width: 500px; height: 500px;
          background: #c9a96e;
          border-radius: 50%;
          filter: blur(100px);
          opacity: 0.07;
          top: -120px; right: -100px;
          pointer-events: none;
        }

        .up-layout {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 2rem;
          width: 100%;
          max-width: 1100px;
          position: relative;
          z-index: 1;
          animation: cardIn 0.45s cubic-bezier(.22,.68,0,1.2) both;
        }

        @keyframes cardIn {
          from { opacity: 0; transform: translateY(20px) scale(0.98); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        .up-card {
          background: #161616;
          border: 1px solid #222;
          border-radius: 20px;
          padding: 2.5rem 2.2rem;
          box-shadow: 0 32px 80px rgba(0,0,0,0.5);
        }

        .up-eyebrow {
          font-size: 0.65rem;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: #c9a96e;
          margin-bottom: 0.4rem;
        }

        .up-heading {
          font-family: 'DM Serif Display', serif;
          font-size: 1.9rem;
          color: #f0ece4;
          letter-spacing: -0.02em;
          margin-bottom: 0.2rem;
          line-height: 1;
        }

        .up-heading em { font-style: italic; color: #c9a96e; }

        .up-sub {
          font-size: 0.8rem;
          color: #555;
          margin-bottom: 1.8rem;
        }

        .up-divider {
          height: 1px;
          background: #222;
          margin-bottom: 1.75rem;
        }

        .up-error {
          background: rgba(220,80,80,0.08);
          border: 1px solid rgba(220,80,80,0.25);
          border-radius: 9px;
          padding: 0.65rem 0.9rem;
          font-size: 0.81rem;
          color: #e07070;
          margin-bottom: 1.25rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          animation: shake 0.3s ease;
        }

        @keyframes shake {
          0%,100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }

        .field { margin-bottom: 1.1rem; }

        .field-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .field-label {
          display: block;
          font-size: 0.67rem;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #666;
          margin-bottom: 0.38rem;
        }

        .field-input,
        .field-textarea {
          width: 100%;
          background: #0d0d0d;
          border: 1px solid #2a2a2a;
          border-radius: 9px;
          padding: 0.65rem 0.95rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.85rem;
          color: #f0ece4;
          outline: none;
          box-sizing: border-box;
          transition: border-color 0.2s, box-shadow 0.2s;
          resize: none;
        }

        .field-input::placeholder,
        .field-textarea::placeholder { color: #333; }

        .field-input:focus,
        .field-textarea:focus {
          border-color: #c9a96e;
          box-shadow: 0 0 0 3px rgba(201,169,110,0.1);
        }

        .price-wrap {
          position: relative;
        }

        .price-prefix {
          position: absolute;
          left: 0.95rem;
          top: 50%;
          transform: translateY(-50%);
          font-size: 0.85rem;
          color: #555;
          pointer-events: none;
          font-weight: 500;
        }

        .price-wrap .field-input { padding-left: 1.8rem; }

        .field-error {
          font-size: 0.71rem;
          color: #e07070;
          margin-top: 0.28rem;
        }

        /* Image Toggle */
        .image-toggle {
          display: flex;
          gap: 1rem;
          margin-bottom: 1rem;
          padding: 0.8rem;
          background: #0a0a0a;
          border: 1px solid #2a2a2a;
          border-radius: 9px;
        }

        .toggle-btn {
          flex: 1;
          padding: 0.5rem;
          border: 1px solid #2a2a2a;
          background: transparent;
          color: #666;
          border-radius: 6px;
          font-size: 0.75rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          text-transform: uppercase;
          letter-spacing: 0.1em;
        }

        .toggle-btn.active {
          background: #c9a96e;
          color: #0d0d0d;
          border-color: #c9a96e;
        }

        /* File Upload */
        .file-input-wrap {
          position: relative;
          border: 2px dashed #2a2a2a;
          border-radius: 9px;
          padding: 2rem;
          text-align: center;
          transition: all 0.2s;
          cursor: pointer;
          display: block;
        }

        .file-input-wrap:hover {
          border-color: #c9a96e;
          background: rgba(201, 169, 110, 0.02);
        }

        .file-input-wrap input[type="file"] {
          display: none;
        }

        .file-input-icon {
          width: 40px;
          height: 40px;
          margin: 0 auto 0.5rem;
          color: #c9a96e;
        }

        .file-input-text {
          font-size: 0.8rem;
          color: #666;
        }

        .file-input-text strong {
          display: block;
          color: #f0ece4;
          margin-bottom: 0.2rem;
        }

        .file-name {
          font-size: 0.75rem;
          color: #c9a96e;
          margin-top: 0.5rem;
        }

        /* Stock & Expense Row */
        .stock-expense-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .btn-update {
          width: 100%;
          background: #c9a96e;
          border: none;
          border-radius: 9px;
          padding: 0.78rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.88rem;
          font-weight: 600;
          color: #0d0d0d;
          cursor: pointer;
          margin-top: 0.5rem;
          transition: background 0.2s, transform 0.15s, opacity 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          letter-spacing: 0.02em;
        }

        .btn-update:hover:not(:disabled) { background: #debb85; transform: translateY(-1px); }
        .btn-update:active:not(:disabled) { transform: translateY(0); }
        .btn-update:disabled { opacity: 0.6; cursor: not-allowed; }

        .btn-cancel {
          width: 100%;
          background: transparent;
          border: 1px solid #2a2a2a;
          border-radius: 9px;
          padding: 0.78rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.88rem;
          font-weight: 600;
          color: #aaa;
          cursor: pointer;
          margin-top: 0.5rem;
          transition: border-color 0.2s, color 0.2s;
        }

        .btn-cancel:hover { border-color: #555; color: #f0ece4; }

        .spinner {
          width: 15px; height: 15px;
          border: 2px solid rgba(0,0,0,0.2);
          border-top-color: #0d0d0d;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
          flex-shrink: 0;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        /* Preview */
        .up-preview {
          position: sticky;
          top: 3.5rem;
        }

        .preview-label {
          display: block;
          font-size: 0.65rem;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: #666;
          margin-bottom: 0.8rem;
        }

        .preview-card {
          background: #161616;
          border: 1px solid #222;
          border-radius: 16px;
          overflow: hidden;
          transition: border-color 0.3s;
        }

        .preview-card.has-image { border-color: #2a2a2a; }

        .preview-img {
          width: 100%;
          aspect-ratio: 4/3;
          object-fit: cover;
          display: block;
          background: #111;
        }

        .preview-img-placeholder {
          width: 100%;
          aspect-ratio: 4/3;
          background: #111;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          color: #333;
          font-size: 0.78rem;
        }

        .preview-body {
          padding: 1.1rem 1.2rem 1.3rem;
        }

        .preview-cat {
          font-size: 0.6rem;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: #c9a96e;
          margin-bottom: 0.3rem;
        }

        .preview-name {
          font-family: 'DM Serif Display', serif;
          font-size: 1.1rem;
          color: #f0ece4;
          margin-bottom: 0.3rem;
          line-height: 1.2;
        }

        .preview-desc {
          font-size: 0.78rem;
          color: #555;
          line-height: 1.5;
          margin-bottom: 0.9rem;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .preview-price {
          font-size: 1.15rem;
          font-weight: 600;
          color: #f0ece4;
        }

        .preview-price span { font-size: 0.78rem; color: #555; margin-right: 2px; }

        .preview-meta {
          margin-top: 1rem;
          padding-top: 1rem;
          border-top: 1px solid #222;
          font-size: 0.75rem;
          color: #666;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .preview-meta-item strong {
          color: #c9a96e;
        }

        @media (max-width: 720px) {
          .up-layout { grid-template-columns: 1fr; }
          .up-preview { position: static; }
          .field-row { grid-template-columns: 1fr; }
        }
      `}</style>

      <div className="up-page">
        <div className="up-layout">

          {/* ── FORM CARD ── */}
          <div className="up-card">
            <p className="up-eyebrow">Admin panel</p>
            <h1 className="up-heading">Update <em>product</em></h1>
            <p className="up-sub">Edit the product details below.</p>
            <div className="up-divider" />

            {submitError && (
              <div className="up-error">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="8" x2="12" y2="12"/>
                  <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                {submitError}
              </div>
            )}

            {productDetails && (
              <form onSubmit={handleSubmit(updateProduct)} noValidate>

                {/* Name */}
                <div className="field">
                  <label className="field-label">Product name</label>
                  <input
                    type="text"
                    className={`field-input ${errors.name ? 'has-error' : ''}`}
                    {...register('name', { required: "Product name is required" })}
                  />
                  {errors.name && <p className="field-error">{errors.name.message}</p>}
                </div>

                {/* Category + Price row */}
                <div className="field-row">
                  <div className="field">
                    <label className="field-label">Category</label>
                    <input
                      type="text"
                      className={`field-input ${errors.category ? 'has-error' : ''}`}
                      {...register('category', { required: "Category is required" })}
                    />
                    {errors.category && <p className="field-error">{errors.category.message}</p>}
                  </div>

                  <div className="field">
                    <label className="field-label">Price (₹)</label>
                    <div className="price-wrap">
                      <span className="price-prefix">₹</span>
                      <input
                        type="number"
                        min="0"
                        className={`field-input ${errors.price ? 'has-error' : ''}`}
                        {...register('price', {
                          required: "Price is required",
                          min: { value: 1, message: "Must be greater than 0" }
                        })}
                      />
                    </div>
                    {errors.price && <p className="field-error">{errors.price.message}</p>}
                  </div>
                </div>

                {/* Stock + Expense */}
                <div className="stock-expense-row">
                  <div className="field">
                    <label className="field-label">Stock (Units)</label>
                    <input
                      type="number"
                      placeholder="0"
                      min="0"
                      className={`field-input ${errors.stock ? 'has-error' : ''}`}
                      {...register('stock')}
                    />
                    {errors.stock && <p className="field-error">{errors.stock.message}</p>}
                  </div>

                  <div className="field">
                    <label className="field-label">Expense per Unit (₹)</label>
                    <div className="price-wrap">
                      <span className="price-prefix">₹</span>
                      <input
                        type="number"
                        placeholder="0"
                        min="0"
                        className={`field-input ${errors.expense ? 'has-error' : ''}`}
                        {...register('expense')}
                      />
                    </div>
                    {errors.expense && <p className="field-error">{errors.expense.message}</p>}
                  </div>
                </div>

                {/* Description */}
                <div className="field">
                  <label className="field-label">Description</label>
                  <textarea
                    rows="3"
                    className={`field-textarea ${errors.description ? 'has-error' : ''}`}
                    {...register('description', { required: "Description is required" })}
                  ></textarea>
                  {errors.description && <p className="field-error">{errors.description.message}</p>}
                </div>

                {/* Image Toggle */}
                <div className="image-toggle">
                  <button
                    type="button"
                    className={`toggle-btn ${!useFileUpload ? 'active' : ''}`}
                    onClick={() => {
                      setUseFileUpload(false);
                      setUploadedImage(null);
                    }}
                  >
                    📎 URL
                  </button>
                  <button
                    type="button"
                    className={`toggle-btn ${useFileUpload ? 'active' : ''}`}
                    onClick={() => {
                      setUseFileUpload(true);
                      setValue('imageUrl', '');
                    }}
                  >
                    📤 Upload
                  </button>
                </div>

                {/* Image Input */}
                {!useFileUpload ? (
                  <div className="field">
                    <label className="field-label">Image URL</label>
                    <input
                      type="url"
                      className={`field-input ${errors.imageUrl ? 'has-error' : ''}`}
                      {...register('imageUrl')}
                    />
                    {errors.imageUrl && <p className="field-error">{errors.imageUrl.message}</p>}
                  </div>
                ) : (
                  <div className="field">
                    <label className="field-label">Upload Image</label>
                    <label htmlFor="imageFile" className="file-input-wrap">
                      <svg className="file-input-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                      </svg>
                      <div className="file-input-text">
                        <strong>Click to upload</strong> or drag and drop
                      </div>
                      {uploadedImage && (
                        <div className="file-name">
                          ✓ {uploadedImage.name}
                        </div>
                      )}
                      <input
                        id="imageFile"
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                      />
                    </label>
                  </div>
                )}

                <button type="submit" className="btn-update" disabled={loading}>
                  {loading ? (
                    <><div className="spinner" /> Updating…</>
                  ) : (
                    <>
                      Update product
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <line x1="5" y1="12" x2="19" y2="12"/>
                        <polyline points="12 5 19 12 12 19"/>
                      </svg>
                    </>
                  )}
                </button>

                <button type="button" className="btn-cancel" onClick={() => navigate("/")}>
                  Cancel
                </button>

              </form>
            )}
          </div>

          {/* ── LIVE PREVIEW ── */}
          <div className="up-preview">
            <span className="preview-label">Live preview</span>
            <div className={`preview-card ${previewImageUrl ? 'has-image' : ''}`}>
              {previewImageUrl ? (
                <img
                  className="preview-img"
                  src={previewImageUrl}
                  alt="preview"
                  onError={(e) => { e.target.style.display = 'none'; }}
                />
              ) : (
                <div className="preview-img-placeholder">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                    <rect x="3" y="3" width="18" height="18" rx="2"/>
                    <circle cx="8.5" cy="8.5" r="1.5"/>
                    <polyline points="21 15 16 10 5 21"/>
                  </svg>
                  {useFileUpload ? "Upload an image to preview" : "Update image URL to preview"}
                </div>
              )}

              {productDetails && (
                <div className="preview-body">
                  <p className="preview-cat">{watch("category") || productDetails.category}</p>
                  <h3 className="preview-name">
                    {watch("name") || productDetails.name}
                  </h3>
                  <p className="preview-desc">
                    {watch("description") || productDetails.description}
                  </p>
                  <div className="preview-price">
                    <span>₹</span>
                    {watch("price") ? Number(watch("price")).toLocaleString('en-IN') : productDetails.price}
                  </div>

                  {(watch("stock") || watch("expense")) && (
                    <div className="preview-meta">
                      {watch("stock") && (
                        <div>
                          <strong>Stock:</strong> {watch("stock")} units
                        </div>
                      )}
                      {watch("expense") && (
                        <div>
                          <strong>Cost:</strong> ₹{Number(watch("expense")).toLocaleString('en-IN')}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </>
  );
}
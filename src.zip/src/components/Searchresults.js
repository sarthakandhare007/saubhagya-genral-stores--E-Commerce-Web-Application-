import React, { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import Product from "./Product";

export default function SearchResults() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get("q");
  const [products, setProducts] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = `
      @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

      .search-page {
        max-width: 1400px;
        margin: 0 auto;
        padding: 2rem 2rem 4rem;
        font-family: 'DM Sans', sans-serif;
      }

      .search-header {
        margin-bottom: 2.5rem;
      }

      .back-button {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: transparent;
        border: 1px solid #333;
        color: #999;
        padding: 0.6rem 1.2rem;
        border-radius: 8px;
        font-size: 0.85rem;
        cursor: pointer;
        transition: all 0.2s;
        margin-bottom: 1.5rem;
      }

      .back-button:hover {
        border-color: #c9a96e;
        color: #c9a96e;
      }

      .search-title-section {
        padding-bottom: 1.5rem;
        border-bottom: 1px solid #2a2a2a;
      }

      .search-title {
        font-family: 'DM Serif Display', serif;
        font-size: clamp(1.8rem, 4vw, 2.5rem);
        color: #f0ece4;
        letter-spacing: -0.02em;
        line-height: 1.2;
        margin-bottom: 0.5rem;
      }

      .search-query {
        color: #c9a96e;
      }

      .search-count {
        font-size: 0.9rem;
        color: #666;
      }

      .search-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
        gap: 1.5rem;
        margin-top: 2rem;
      }

      .empty-state {
        text-align: center;
        padding: 5rem 2rem;
        color: #444;
        grid-column: 1/-1;
      }

      .empty-state svg {
        margin-bottom: 1.5rem;
        opacity: 0.3;
      }

      .empty-state h3 {
        font-family: 'DM Serif Display', serif;
        font-size: 1.5rem;
        color: #666;
        margin-bottom: 0.5rem;
      }

      .empty-state p {
        font-size: 0.95rem;
        color: #555;
        margin-bottom: 1.5rem;
      }

      .suggestions {
        margin-top: 1rem;
      }

      .suggestions-title {
        font-size: 0.85rem;
        color: #666;
        margin-bottom: 0.8rem;
      }

      .suggestion-chips {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        justify-content: center;
      }

      .suggestion-chip {
        background: #161616;
        border: 1px solid #2a2a2a;
        color: #999;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.85rem;
        cursor: pointer;
        transition: all 0.2s;
      }

      .suggestion-chip:hover {
        border-color: #c9a96e;
        color: #c9a96e;
      }

      .skeleton-card {
        background: #161616;
        border-radius: 14px;
        height: 340px;
        position: relative;
        overflow: hidden;
      }

      .skeleton-card::after {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(90deg, transparent 0%, #222 50%, transparent 100%);
        animation: shimmer 1.4s infinite;
      }

      @keyframes shimmer {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100%); }
      }

      @media (max-width: 768px) {
        .search-page { padding: 1rem 1rem 3rem; }
        .search-grid { grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); }
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  useEffect(() => {
    if (!query) return;

    setIsLoading(true);
    const params = new URLSearchParams();
    params.append("name", query);

    fetch(`http://localhost:8080/api/search-products?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        setProducts(d);
        setIsLoading(false);
      })
      .catch(err => {
        console.error("Error fetching search results:", err);
        setIsLoading(false);
      });
  }, [query]);

  const popularSearches = ["Electronics", "Furniture", "Clothing", "Books", "Kitchen"];

  return (
    <div className="search-page">
      <div className="search-header">
        <button className="back-button" onClick={() => navigate("/")}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="19" y1="12" x2="5" y2="12"/>
            <polyline points="12 19 5 12 12 5"/>
          </svg>
          Back to Home
        </button>

        <div className="search-title-section">
          <h1 className="search-title">
            Search results for "<span className="search-query">{query}</span>"
          </h1>
          {!isLoading && products && (
            <p className="search-count">
              {products.length} {products.length === 1 ? 'product' : 'products'} found
            </p>
          )}
        </div>
      </div>

      <div className="search-grid">
        {isLoading
          ? Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="skeleton-card" />
            ))
          : products && products.length > 0
          ? products.map((prod) => <Product key={prod.id} prod={prod} />)
          : (
              <div className="empty-state">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <circle cx="11" cy="11" r="8" />
                  <line x1="21" y1="21" x2="16.65" y2="16.65" />
                  <line x1="4" y1="4" x2="20" y2="20" />
                </svg>
                <h3>No results found</h3>
                <p>We couldn't find any products matching "{query}"</p>
                
                <div className="suggestions">
                  <p className="suggestions-title">Try searching for:</p>
                  <div className="suggestion-chips">
                    {popularSearches.map(search => (
                      <div
                        key={search}
                        className="suggestion-chip"
                        onClick={() => navigate(`/search?q=${encodeURIComponent(search)}`)}
                      >
                        {search}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )
        }
      </div>
    </div>
  );
}
import { useLocation } from "react-router-dom";

export default function CustomerLedger() {
  const { state } = useLocation();
  const { customerName, records } = state;

  const totalPending = records
    .filter(r => r.status === "PENDING")
    .reduce((sum, r) => sum + r.amount, 0);

  return (
    <div className="container mt-3">
      <h2>{customerName} Ledger</h2>
      <h4>Pending ₹ {totalPending}</h4>
      <table className="table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Product</th>
            <th>Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {records.map((r, i) => (
            <tr key={i}>
              <td>{new Date(r.date).toLocaleString()}</td>
              <td>{r.productName}</td>
              <td>₹ {r.amount}</td>
              <td>{r.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

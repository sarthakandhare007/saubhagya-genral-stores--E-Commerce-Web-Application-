import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';

export default function Product({ prod: product }) {
  const [imgError, setImgError] = useState(false);
  const [added, setAdded] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const navigate = useNavigate();

  const roles = localStorage.getItem("roles");
  const token = localStorage.getItem("jwtToken");
  const userId = localStorage.getItem("userId");

  function handleAddToCart(e) {
    e.preventDefault();
    e.stopPropagation();
    
    if (!roles || !roles.includes("USER")) {
      alert("Please login first to add items to cart");
      navigate("/login");
      return;
    }

    if (!token || !userId) {
      alert("Please login first");
      navigate("/login");
      return;
    }

    setIsAdding(true);

    const requestBody = {
      "user": `http://localhost:8080/api/users/${userId}`,
      "product": `http://localhost:8080/api/products/${product.id}`
    };

    fetch('http://localhost:8080/api/carts', {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
      },
      method: "POST",
      body: JSON.stringify(requestBody)
    })
    .then(resp => {
      if (resp.ok) {
        setAdded(true);
        setTimeout(() => setAdded(false), 2000);
      } else if (resp.status === 401) {
        alert("Session expired. Please login again.");
        navigate("/login");
      } else {
        alert("Failed to add product to cart");
      }
    })
    .catch(error => {
      console.error("Error adding to cart:", error);
      alert("An error occurred. Please try again.");
    })
    .finally(() => {
      setIsAdding(false);
    });
  }

  return (
    <>
      <style>{`
        .product-card {
          background: #161616;
          border: 1px solid #222;
          border-radius: 14px;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          transition: border-color 0.25s, transform 0.25s, box-shadow 0.25s;
          height: 100%;
        }

        .product-card:hover {
          border-color: #c9a96e;
          transform: translateY(-4px);
          box-shadow: 0 16px 40px rgba(0,0,0,0.5);
        }

        .product-img-wrap {
          position: relative;
          overflow: hidden;
          aspect-ratio: 4/3;
          background: #111;
        }

        .product-img-wrap img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 0.45s ease;
        }

        .product-card:hover .product-img-wrap img {
          transform: scale(1.05);
        }

        .product-badge {
          position: absolute;
          top: 0.75rem;
          left: 0.75rem;
          background: #c9a96e;
          color: #0d0d0d;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.6rem;
          font-weight: 700;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          padding: 0.25rem 0.6rem;
          border-radius: 4px;
        }

        .product-body {
          padding: 1.2rem 1.25rem 1.4rem;
          display: flex;
          flex-direction: column;
          flex: 1;
          gap: 0.35rem;
        }

        .product-category {
          font-family: 'DM Sans', sans-serif;
          font-size: 0.62rem;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: #c9a96e;
          font-weight: 500;
        }

        .product-name {
          font-family: 'DM Serif Display', serif;
          font-size: 1.1rem;
          color: #f0ece4;
          line-height: 1.25;
          margin: 0;
        }

        .product-desc {
          font-family: 'DM Sans', sans-serif;
          font-size: 0.8rem;
          color: #666;
          line-height: 1.55;
          margin: 0.1rem 0 0;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .product-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: auto;
          padding-top: 1rem;
          border-top: 1px solid #222;
        }

        .product-price {
          font-family: 'DM Sans', sans-serif;
          font-size: 1.2rem;
          font-weight: 600;
          color: #f0ece4;
          letter-spacing: -0.01em;
        }

        .product-price span {
          font-size: 0.78rem;
          color: #555;
          font-weight: 400;
          margin-right: 2px;
        }

        .product-actions {
          display: flex;
          gap: 0.5rem;
        }

        .btn-details {
          background: transparent;
          border: 1px solid #333;
          border-radius: 7px;
          padding: 0.45rem 0.8rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.78rem;
          color: #aaa;
          text-decoration: none;
          transition: border-color 0.2s, color 0.2s;
          display: flex;
          align-items: center;
          gap: 0.3rem;
          white-space: nowrap;
        }

        .btn-details:hover {
          border-color: #c9a96e;
          color: #c9a96e;
        }

        .btn-cart {
          background: #c9a96e;
          border: none;
          border-radius: 7px;
          padding: 0.45rem 0.85rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.78rem;
          font-weight: 600;
          color: #0d0d0d;
          cursor: pointer;
          transition: background 0.2s, transform 0.15s;
          display: flex;
          align-items: center;
          gap: 0.35rem;
          white-space: nowrap;
        }

        .btn-cart:hover:not(:disabled) { 
          background: #debb85; 
          transform: translateY(-1px); 
        }
        
        .btn-cart:active:not(:disabled) { 
          transform: translateY(0); 
        }

        .btn-cart:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .btn-cart.added {
          background: #3a7d44;
          color: #fff;
        }

        .img-placeholder {
          width: 100%;
          height: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #1a1a1a;
          color: #333;
        }

        .spinner-small {
          width: 12px;
          height: 12px;
          border: 2px solid rgba(0,0,0,0.2);
          border-top-color: #0d0d0d;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>

      <div className="product-card">
        {/* Image */}
        <div className="product-img-wrap">
          {!imgError ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="img-placeholder">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                <rect x="3" y="3" width="18" height="18" rx="2" />
                <circle cx="8.5" cy="8.5" r="1.5" />
                <polyline points="21 15 16 10 5 21" />
              </svg>
            </div>
          )}
          {product.category && (
            <span className="product-badge">{product.category}</span>
          )}
        </div>

        {/* Body */}
        <div className="product-body">
          <p className="product-category">{product.category}</p>
          <h3 className="product-name">{product.name}</h3>
          <p className="product-desc">{product.description}</p>

          {/* Footer: price + actions */}
          <div className="product-footer">
            <div className="product-price">
              <span>₹</span>{Number(product.price).toLocaleString('en-IN')}
            </div>

            <div className="product-actions">
              <NavLink to={`/details/${product.id}`} className="btn-details">
                View
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="5" y1="12" x2="19" y2="12" />
                  <polyline points="12 5 19 12 12 19" />
                </svg>
              </NavLink>

              <button
                className={`btn-cart ${added ? 'added' : ''}`}
                onClick={handleAddToCart}
                disabled={isAdding || added}
              >
                {isAdding ? (
                  <>
                    <div className="spinner-small" />
                    Adding...
                  </>
                ) : added ? (
                  <>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <polyline points="20 6 9 17 4 12" />
                    </svg>
                    Added
                  </>
                ) : (
                  <>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
                      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                    </svg>
                    Add
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';

export default function AddProduct() {
  const { register, handleSubmit, watch, formState: { errors } } = useForm();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState(null);

  const imageUrlValue = watch("imageUrl");

  async function addNewProduct(formData) {
    setSubmitError(null);
    setLoading(true);
    try {
      const token = localStorage.getItem("jwtToken");
      const resp = await fetch('http://localhost:8080/api/products', {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        method: "POST",
        body: JSON.stringify({ ...formData, price: Number(formData.price) })
      });
      if (resp.status === 201) {
        navigate("/", { state: { added: true } });
      } else {
        setSubmitError("Failed to add product. Please try again.");
      }
    } catch {
      setSubmitError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

        .ap-page {
          min-height: 100vh;
          background: #0d0d0d;
          display: flex;npm
          align-items: flex-start;
          justify-content: center;
          padding: 3.5rem 1rem 5rem;
          font-family: 'DM Sans', sans-serif;
          position: relative;
          overflow: hidden;
        }

        .ap-page::before {
          content: '';
          position: absolute;
          width: 500px; height: 500px;
          background: #c9a96e;
          border-radius: 50%;
          filter: blur(100px);
          opacity: 0.07;
          top: -120px; right: -100px;
          pointer-events: none;
        }

        .ap-layout {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 2rem;
          width: 100%;
          max-width: 900px;
          position: relative;
          z-index: 1;
          animation: cardIn 0.45s cubic-bezier(.22,.68,0,1.2) both;
        }

        @keyframes cardIn {
          from { opacity: 0; transform: translateY(20px) scale(0.98); }
          to   { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* ── LEFT: FORM ── */
        .ap-card {
          background: #161616;
          border: 1px solid #222;
          border-radius: 20px;
          padding: 2.5rem 2.2rem;
          box-shadow: 0 32px 80px rgba(0,0,0,0.5);
        }

        .ap-eyebrow {
          font-size: 0.65rem;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: #c9a96e;
          margin-bottom: 0.4rem;
        }

        .ap-heading {
          font-family: 'DM Serif Display', serif;
          font-size: 1.9rem;
          color: #f0ece4;
          letter-spacing: -0.02em;
          margin-bottom: 0.2rem;
          line-height: 1;
        }

        .ap-heading em { font-style: italic; color: #c9a96e; }

        .ap-sub {
          font-size: 0.8rem;
          color: #555;
          margin-bottom: 1.8rem;
        }

        .ap-divider {
          height: 1px;
          background: #222;
          margin-bottom: 1.75rem;
        }

        /* ── ERROR ── */
        .ap-error {
          background: rgba(220,80,80,0.08);
          border: 1px solid rgba(220,80,80,0.25);
          border-radius: 9px;
          padding: 0.65rem 0.9rem;
          font-size: 0.81rem;
          color: #e07070;
          margin-bottom: 1.25rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          animation: shake 0.3s ease;
        }

        @keyframes shake {
          0%,100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }

        /* ── FIELDS ── */
        .field { margin-bottom: 1.1rem; }

        .field-row {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .field-label {
          display: block;
          font-size: 0.67rem;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #666;
          margin-bottom: 0.38rem;
        }

        .field-input,
        .field-textarea {
          width: 100%;
          background: #0d0d0d;
          border: 1px solid #2a2a2a;
          border-radius: 9px;
          padding: 0.65rem 0.95rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.85rem;
          color: #f0ece4;
          outline: none;
          box-sizing: border-box;
          transition: border-color 0.2s, box-shadow 0.2s;
          resize: none;
        }

        .field-input::placeholder,
        .field-textarea::placeholder { color: #333; }

        .field-input:focus,
        .field-textarea:focus {
          border-color: #c9a96e;
          box-shadow: 0 0 0 3px rgba(201,169,110,0.1);
        }

        .field-input.has-error,
        .field-textarea.has-error {
          border-color: rgba(220,80,80,0.45);
        }

        /* price prefix */
        .price-wrap {
          position: relative;
        }

        .price-prefix {
          position: absolute;
          left: 0.95rem;
          top: 50%;
          transform: translateY(-50%);
          font-size: 0.85rem;
          color: #555;
          pointer-events: none;
          font-weight: 500;
        }

        .price-wrap .field-input { padding-left: 1.8rem; }

        .field-error {
          font-size: 0.71rem;
          color: #e07070;
          margin-top: 0.28rem;
        }

        /* ── SUBMIT ── */
        .btn-add {
          width: 100%;
          background: #c9a96e;
          border: none;
          border-radius: 9px;
          padding: 0.78rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.88rem;
          font-weight: 600;
          color: #0d0d0d;
          cursor: pointer;
          margin-top: 0.5rem;
          transition: background 0.2s, transform 0.15s, opacity 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          letter-spacing: 0.02em;
        }

        .btn-add:hover:not(:disabled) { background: #debb85; transform: translateY(-1px); }
        .btn-add:active:not(:disabled) { transform: translateY(0); }
        .btn-add:disabled { opacity: 0.6; cursor: not-allowed; }

        .spinner {
          width: 15px; height: 15px;
          border: 2px solid rgba(0,0,0,0.2);
          border-top-color: #0d0d0d;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        .btn-cancel {
          width: 100%;
          background: transparent;
          border: 1px solid #2a2a2a;
          border-radius: 9px;
          padding: 0.65rem 1rem;
          font-family: 'DM Sans', sans-serif;
          font-size: 0.85rem;
          color: #666;
          cursor: pointer;
          margin-top: 0.6rem;
          transition: color 0.2s, border-color 0.2s;
        }

        .btn-cancel:hover { color: #f0ece4; border-color: #555; }

        /* ── RIGHT: PREVIEW ── */
        .ap-preview {
          position: sticky;
          top: 2rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .preview-label {
          font-size: 0.65rem;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: #444;
        }

        .preview-card {
          background: #161616;
          border: 1px solid #222;
          border-radius: 16px;
          overflow: hidden;
          transition: border-color 0.3s;
        }

        .preview-card.has-image { border-color: #2a2a2a; }

        .preview-img {
          width: 100%;
          aspect-ratio: 4/3;
          object-fit: cover;
          display: block;
          background: #111;
        }

        .preview-img-placeholder {
          width: 100%;
          aspect-ratio: 4/3;
          background: #111;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          color: #333;
          font-size: 0.78rem;
        }

        .preview-body {
          padding: 1.1rem 1.2rem 1.3rem;
        }

        .preview-cat {
          font-size: 0.6rem;
          letter-spacing: 0.15em;
          text-transform: uppercase;
          color: #c9a96e;
          margin-bottom: 0.3rem;
        }

        .preview-name {
          font-family: 'DM Serif Display', serif;
          font-size: 1.1rem;
          color: #f0ece4;
          margin-bottom: 0.3rem;
          line-height: 1.2;
        }

        .preview-desc {
          font-size: 0.78rem;
          color: #555;
          line-height: 1.5;
          margin-bottom: 0.9rem;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .preview-price {
          font-size: 1.15rem;
          font-weight: 600;
          color: #f0ece4;
        }

        .preview-price span { font-size: 0.78rem; color: #555; margin-right: 2px; }

        .preview-empty-name {
          color: #333;
          font-style: italic;
        }

        /* ── RESPONSIVE ── */
        @media (max-width: 720px) {
          .ap-layout { grid-template-columns: 1fr; }
          .ap-preview { position: static; }
          .field-row { grid-template-columns: 1fr; }
        }
      `}</style>

      <div className="ap-page">
        <div className="ap-layout">

          {/* ── FORM CARD ── */}
          <div className="ap-card">
            <p className="ap-eyebrow">Admin panel</p>
            <h1 className="ap-heading">Add <em>product</em></h1>
            <p className="ap-sub">Fill in the details to list a new item.</p>
            <div className="ap-divider" />

            {submitError && (
              <div className="ap-error">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <circle cx="12" cy="12" r="10"/>
                  <line x1="12" y1="8" x2="12" y2="12"/>
                  <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                {submitError}
              </div>
            )}

            <form onSubmit={handleSubmit(addNewProduct)} noValidate>

              {/* Name */}
              <div className="field">
                <label className="field-label">Product name</label>
                <input
                  type="text"
                  placeholder="e.g. Wireless Headphones"
                  className={`field-input ${errors.name ? 'has-error' : ''}`}
                  {...register('name', { required: "Product name is required" })}
                />
                {errors.name && <p className="field-error">{errors.name.message}</p>}
              </div>

              {/* Category + Price row */}
              <div className="field-row">
                <div className="field">
                  <label className="field-label">Category</label>
                  <input
                    type="text"
                    placeholder="e.g. Electronics"
                    className={`field-input ${errors.category ? 'has-error' : ''}`}
                    {...register('category', { required: "Category is required" })}
                  />
                  {errors.category && <p className="field-error">{errors.category.message}</p>}
                </div>

                <div className="field">
                  <label className="field-label">Price (₹)</label>
                  <div className="price-wrap">
                    <span className="price-prefix">₹</span>
                    <input
                      type="number"
                      placeholder="0"
                      min="0"
                      className={`field-input ${errors.price ? 'has-error' : ''}`}
                      {...register('price', {
                        required: "Price is required",
                        min: { value: 1, message: "Must be greater than 0" }
                      })}
                    />
                  </div>
                  {errors.price && <p className="field-error">{errors.price.message}</p>}
                </div>
              </div>

              {/* Description */}
              <div className="field">
                <label className="field-label">Description</label>
                <textarea
                  rows="3"
                  placeholder="Describe the product briefly…"
                  className={`field-textarea ${errors.description ? 'has-error' : ''}`}
                  {...register('description', { required: "Description is required" })}
                />
                {errors.description && <p className="field-error">{errors.description.message}</p>}
              </div>

              {/* Image URL */}
              <div className="field">
                <label className="field-label">Image URL</label>
                <input
                  type="url"
                  placeholder="https://example.com/image.jpg"
                  className={`field-input ${errors.imageUrl ? 'has-error' : ''}`}
                  {...register('imageUrl', { required: "Image URL is required" })}
                />
                {errors.imageUrl && <p className="field-error">{errors.imageUrl.message}</p>}
              </div>

              <button type="submit" className="btn-add" disabled={loading}>
                {loading ? (
                  <><div className="spinner" /> Adding product…</>
                ) : (
                  <>
                    Add product
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <line x1="5" y1="12" x2="19" y2="12"/>
                      <polyline points="12 5 19 12 12 19"/>
                    </svg>
                  </>
                )}
              </button>

              <button type="button" className="btn-cancel" onClick={() => navigate("/")}>
                Cancel
              </button>

            </form>
          </div>

          {/* ── LIVE PREVIEW ── */}
          <div className="ap-preview">
            <span className="preview-label">Live preview</span>
            <div className={`preview-card ${imageUrlValue ? 'has-image' : ''}`}>
              {imageUrlValue ? (
                <img
                  className="preview-img"
                  src={imageUrlValue}
                  alt="preview"
                  onError={(e) => { e.target.style.display = 'none'; }}
                />
              ) : (
                <div className="preview-img-placeholder">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                    <rect x="3" y="3" width="18" height="18" rx="2"/>
                    <circle cx="8.5" cy="8.5" r="1.5"/>
                    <polyline points="21 15 16 10 5 21"/>
                  </svg>
                  Paste an image URL to preview
                </div>
              )}

              <div className="preview-body">
                <p className="preview-cat">{watch("category") || "Category"}</p>
                <h3 className="preview-name">
                  {watch("name")
                    ? watch("name")
                    : <span className="preview-empty-name">Product name</span>
                  }
                </h3>
                <p className="preview-desc">
                  {watch("description") || "Product description will appear here…"}
                </p>
                <div className="preview-price">
                  <span>₹</span>
                  {watch("price") ? Number(watch("price")).toLocaleString('en-IN') : "0"}
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </>
  );
}
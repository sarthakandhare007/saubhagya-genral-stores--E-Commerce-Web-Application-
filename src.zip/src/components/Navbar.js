import React from 'react'
import { NavLink } from 'react-router-dom'

export default function Navbar() {
  const token = localStorage.getItem("jwtToken");
  console.log("navbar:", token);
  const roles = localStorage.getItem("roles");

  function doLogout() {
    localStorage.clear();
    window.location.href = "http://localhost:3000";
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

        .navbar {
          background: #161616 !important;
          border-bottom: 1px solid #222 !important;
          padding: 1rem 0 !important;
          font-family: 'DM Sans', sans-serif !important;
        }

        .navbar-brand {
          font-family: 'DM Serif Display', serif !important;
          font-size: 1.4rem !important;
          color: #f0ece4 !important;
          letter-spacing: -0.02em !important;
          font-weight: 600 !important;
        }

        .navbar-brand:hover {
          color: #c9a96e !important;
        }

        .nav-link {
          color: #999 !important;
          font-size: 0.9rem !important;
          transition: color 0.2s !important;
          position: relative !important;
        }

        .nav-link:hover,
        .nav-link.active {
          color: #c9a96e !important;
        }

        .nav-link.active::after {
          content: '';
          position: absolute;
          bottom: -8px;
          left: 0;
          right: 0;
          height: 2px;
          background: #c9a96e;
        }

        .nav-link:not(.active):hover::after {
          content: '';
          position: absolute;
          bottom: -8px;
          left: 0;
          right: 0;
          height: 1px;
          background: #c9a96e;
          opacity: 0.5;
        }

        /* Logout button styling */
        .nav-link[onclick] {
          background: transparent !important;
          border: 1px solid #333 !important;
          padding: 0.4rem 0.8rem !important;
          border-radius: 6px !important;
          color: #c9a96e !important;
        }

        .nav-link[onclick]:hover {
          border-color: #c9a96e !important;
          background: rgba(201, 169, 110, 0.05) !important;
        }

        .search-form {
          gap: 0.5rem !important;
        }

        .form-control {
          background: #0d0d0d !important;
          border: 1px solid #2a2a2a !important;
          color: #f0ece4 !important;
          font-size: 0.88rem !important;
        }

        .form-control::placeholder {
          color: #555 !important;
        }

        .form-control:focus {
          background: #0d0d0d !important;
          border-color: #c9a96e !important;
          box-shadow: 0 0 0 3px rgba(201, 169, 110, 0.1) !important;
          color: #f0ece4 !important;
        }

        .btn-outline-success {
          color: #c9a96e !important;
          border-color: #2a2a2a !important;
          background: transparent !important;
        }

        .btn-outline-success:hover {
          background: transparent !important;
          border-color: #c9a96e !important;
          color: #c9a96e !important;
        }

        .navbar-toggler {
          border: 1px solid #333 !important;
          color: #c9a96e !important;
        }

        .navbar-toggler:focus {
          box-shadow: 0 0 0 0.25rem rgba(201, 169, 110, 0.25) !important;
        }

        .navbar-toggler-icon {
          background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(201, 169, 110, 1)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e") !important;
        }

        .navbar-nav {
          gap: 0.5rem !important;
        }

        /* Admin badge */
        .admin-badge {
          display: inline-block;
          background: rgba(201, 169, 110, 0.2);
          color: #c9a96e;
          padding: 0.2rem 0.5rem;
          border-radius: 4px;
          font-size: 0.65rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          margin-left: 0.5rem;
          font-weight: 600;
        }
      `}</style>

      <nav className="navbar navbar-expand-lg">
        <div className="container-fluid">
          <NavLink className="navbar-brand" to="/">ClickToKart</NavLink>

          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">

            <ul className="navbar-nav me-auto mb-2 mb-lg-0">

              <li className="nav-item">
                <NavLink className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} aria-current="page" to={"/"}>Home</NavLink>
              </li>
              {
                !token &&
                <>
                  <li className="nav-item">
                    <NavLink className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} to={"/login"}>Login</NavLink>
                  </li>

                  <li className="nav-item">
                    <NavLink className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} to={"/register"}>Register</NavLink>
                  </li>
                </>
              }
              {
                roles && roles.includes("USER") &&
                <>
                  <li className="nav-item">
                    <NavLink className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} aria-current="page" to={"/mycart"}>My Cart</NavLink>
                  </li>

                  <li className="nav-item">
                    <NavLink className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} aria-current="page" to={"/myorders"}>My Orders</NavLink>
                  </li>
                </>
              }
              {
                roles && roles.includes("ADMIN") &&
                <>
                  <li className="nav-item">
                    <NavLink className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} aria-current="page" to={'/add-product'}>
                      Add Product
                    </NavLink>
                  </li>

                  <li className="nav-item">
                    <NavLink className={({ isActive }) => isActive ? "nav-link active" : "nav-link"} aria-current="page" to={'/admin-ledger'}>
                      📊 Ledger
                    </NavLink>
                  </li>
                </>
              }
              {
                token &&
                <>
                  <li className="nav-item">
                    <button className="nav-link" onClick={doLogout}>Logout</button>
                  </li>
                </>
              }

            </ul>

            {/* <form className="d-flex search-form">
              <input className="form-control me-2" type="search" placeholder="Search" />
              <button className="btn btn-outline-success" type="submit">Search</button>
            </form> */}

          </div>
        </div>
      </nav>
    </>
  )
}

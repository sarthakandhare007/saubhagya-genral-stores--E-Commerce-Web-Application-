
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Home(){
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();

  useEffect(()=>{
    fetch("http://localhost:8080/api/products")
    .then(res=>res.json())
    .then(data=>{
      const unique=[...new Set(data.map(p=>p.category))];
      setCategories(unique);
    })
  },[])

  return (
    <div style={{padding:"20px"}}>
      <h1>Furniture Shop</h1>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:"20px"}}>
        {categories.map(cat=>(
          <div key={cat} onClick={()=>navigate(`/category/${cat}`)} style={{border:"1px solid gray",cursor:"pointer"}}>
            <img src={`https://source.unsplash.com/300x200/?${cat}`} width="100%"/>
            <h3>{cat}</h3>
          </div>
        ))}
      </div>
    </div>
  )
}
